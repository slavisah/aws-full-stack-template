export default {
	MAX_ATTACHMENT_SIZE: 5000000,	
    apiGateway: {
    REGION: 'enter region',
    API_URL: 'enter api url',
    },
    cognito: {
        REGION: 'enter region',
        USER_POOL_ID: 'enter user pool id',
        APP_CLIENT_ID: 'enter app client id',
        IDENTITY_POOL_ID: 'enter identity pool id'
    }
};

